"""Gera a evidência e o gabarito do minicurso, e só grava se o gabarito conferir.

Uso:  python3 gerar.py [--destino saida]
"""

import argparse
import json
from collections import Counter
from pathlib import Path

from aurora.cenario import montar
from aurora.conferencia import ISCAS, conferir, iscas_que_enganam


def main(destino: Path) -> None:
    cenario = montar()
    perguntas = [pergunta for estudo in cenario.estudos for pergunta in estudo.perguntas]
    resultados = conferir(cenario.eventos, perguntas)
    reprovados = [resultado for resultado in resultados if not resultado.confere]
    iscas = iscas_que_enganam(cenario.eventos, perguntas)

    for resultado in resultados:
        marca = "ok " if resultado.confere else "ERRO"
        print(f"  {marca} {resultado.chave:<18} esperado={resultado.esperado!r} obtido={resultado.obtido!r}")
    for chave, engana in iscas.items():
        print(f"  {'ok ' if engana else 'ERRO'} isca de {chave}: {ISCAS[chave][1]} leva a outra resposta")
    if reprovados or not all(iscas.values()):
        raise SystemExit("O gabarito não confere; nada foi gravado.")

    destino.mkdir(parents=True, exist_ok=True)
    (destino / "aurora-telecom.json").write_text(json.dumps(cenario.eventos, ensure_ascii=False))
    (destino / "gabarito.json").write_text(json.dumps([estudo.model_dump() for estudo in cenario.estudos],
                                                      ensure_ascii=False, indent=2))
    por_conjunto = Counter(documento["event"]["dataset"] for documento in cenario.eventos)
    print(f"\n  {len(cenario.eventos)} eventos: {dict(sorted(por_conjunto.items()))}")
    print(f"  gravados em {destino}/")


if __name__ == "__main__":
    analisador = argparse.ArgumentParser(description=__doc__)
    analisador.add_argument("--destino", type=Path, default=Path(__file__).parent / "saida")
    main(analisador.parse_args().destino)
