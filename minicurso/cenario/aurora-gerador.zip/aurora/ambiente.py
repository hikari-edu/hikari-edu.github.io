"""Quem existe na Aurora Telecom: pessoas, estações, servidores e redes."""

import random
from typing import List

from pydantic import BaseModel

NOMES = ["ana", "bruno", "carla", "diego", "elisa", "fabio", "gabriela", "hugo", "ingrid", "joao",
         "karina", "lucas", "marina", "nuno", "olivia", "paulo", "quiteria", "rafael", "sofia", "tiago",
         "ursula", "vitor", "wanda", "xavier", "yara", "zeca", "bianca", "caio", "debora", "eduardo"]
SOBRENOMES = ["moura", "lemos", "prado", "rocha", "teles", "viana", "sales", "matos", "neves", "pires"]


class Pessoa(BaseModel):
    conta: str
    estacao: str
    ip: str


class Ambiente(BaseModel):
    pessoas: List[Pessoa]
    servidores: List[str]
    controladores: List[str]
    servidores_de_arquivos: List[str]


# As pessoas que os ataques envolvem existem desde o começo, com rotina normal:
# a vítima de cada caso também trabalha, loga e navega como as demais.
PROTAGONISTAS = [
    Pessoa(conta="c.moura", estacao="WKS-FIN-121", ip="10.40.0.121"),
    Pessoa(conta="r.lemos", estacao="WKS-ENG-117", ip="10.40.0.117"),
    Pessoa(conta="e.pires", estacao="WKS-ADM-104", ip="10.40.0.140"),
]


def criar_ambiente(sorteio: random.Random) -> Ambiente:
    reservadas = {pessoa.conta for pessoa in PROTAGONISTAS}
    contas = sorted({f"{nome[0]}.{sobrenome}" for nome in NOMES for sobrenome in SOBRENOMES} - reservadas)
    escolhidas = sorteio.sample(contas, 117)
    pessoas = PROTAGONISTAS + [
        Pessoa(conta=conta, estacao=f"WKS-{sorteio.choice(['ENG', 'ADM', 'FIN', 'NOC', 'COM'])}-{200 + indice:03d}",
               ip=f"10.40.1.{10 + indice}")
        for indice, conta in enumerate(escolhidas)
    ]
    return Ambiente(
        pessoas=pessoas,
        servidores=["SRV-FIN-01", "SRV-FIN-02", "SRV-ERP-01", "SRV-MGMT-01", "SRV-WEB-03"],
        controladores=["DC01", "DC02"],
        servidores_de_arquivos=["FS01", "FS02"],
    )
