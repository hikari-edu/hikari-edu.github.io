"""Estudo de caso 2 — O canal que respira.

Um documento aberto no Word solta um executável com nome de atualizador do
OneDrive dentro do perfil do usuário. Ele consulta, a cada cinco minutos, um
domínio que imita a empresa e conversa com um servidor externo na porta 8443.
Na noite seguinte, a mesma estação envia gigabytes em fluxos de tamanho comum.

Três iscas: a atualização legítima, que toda estação consulta de hora em hora;
o OneDriveUpdater legítimo, com o mesmo nome em outro caminho; e o backup e o
espelho de atualização, com os maiores fluxos do período, um interno e o outro
de download.
"""

import random
from datetime import timedelta
from typing import Dict, List

from .ambiente import Ambiente
from .modelo import DIAS_DO_PERIODO, INICIO_DO_PERIODO, evento, momento
from .perguntas import EstudoDeCaso, Pergunta

ESTACAO = "WKS-ENG-117"
ESTACAO_IP = "10.40.0.117"
CONTA = "r.lemos"
DOMINIO_DO_CANAL = "telemetria-aurora-cdn.net"
SERVIDOR_DO_CANAL = "198.51.100.44"
PORTA_DO_CANAL = 8443
INTERVALO_SEGUNDOS = 300
EXECUTAVEL = r"C:\Users\r.lemos\AppData\Roaming\Microsoft\OneDriveUpdater.exe"
HASH_MALICIOSO = "e3b98a4da31a127d4bde6e43033f66ba274cab0eb7eb1c70ec41402bf6273dd8"
PROCESSO_PAI = "WINWORD.EXE"
DESTINO_DA_EXFILTRACAO = "198.51.100.61"
FLUXOS_DE_EXFILTRACAO = 180
INFECCAO = momento(0, 12, 12, 30)
EXFILTRACAO = momento(1, 1, 5)


def _infeccao() -> List[Dict]:
    base = {"host.name": ESTACAO, "user.name": CONTA}
    return [
        evento("edr", INFECCAO, "Processo iniciado",
               {**base, "process.name": PROCESSO_PAI, "process.parent.name": "explorer.exe",
                "process.executable": r"C:\Program Files\Microsoft Office\root\Office16\WINWORD.EXE",
                "process.args": r"C:\Users\r.lemos\Downloads\Reajuste_Contratos_2026.docm"}),
        evento("edr", INFECCAO + timedelta(seconds=41), "Processo iniciado",
               {**base, "process.name": "OneDriveUpdater.exe", "process.parent.name": PROCESSO_PAI,
                "process.executable": EXECUTAVEL, "process.hash.sha256": HASH_MALICIOSO}, severidade=2),
    ]


def _batimentos(sorteio: random.Random) -> List[Dict]:
    eventos = []
    instante = INFECCAO + timedelta(minutes=2)
    fim = INICIO_DO_PERIODO + timedelta(days=DIAS_DO_PERIODO)
    while instante < fim:
        eventos.append(evento("dns", instante, "Consulta DNS resolvida",
                              {"dns.question.name": DOMINIO_DO_CANAL, "source.ip": ESTACAO_IP,
                               "host.name": ESTACAO, "dns.question.type": "A"}))
        eventos.append(evento("firewall", instante + timedelta(milliseconds=180), "Conexão permitida",
                              {"source.ip": ESTACAO_IP, "host.name": ESTACAO, "destination.ip": SERVIDOR_DO_CANAL,
                               "destination.port": PORTA_DO_CANAL, "network.transport": "tcp",
                               "process.name": "OneDriveUpdater.exe",
                               "source.bytes": sorteio.randint(420, 910), "destination.bytes": sorteio.randint(300, 1_400)}))
        instante += timedelta(seconds=INTERVALO_SEGUNDOS + sorteio.randint(-15, 15))
    return eventos


def _exfiltracao(sorteio: random.Random) -> List[Dict]:
    return [
        evento("firewall", EXFILTRACAO + timedelta(seconds=indice * 31), "Conexão permitida",
               {"source.ip": ESTACAO_IP, "host.name": ESTACAO, "destination.ip": DESTINO_DA_EXFILTRACAO,
                "destination.port": 443, "network.transport": "tcp", "process.name": "OneDriveUpdater.exe",
                "source.bytes": sorteio.randint(11_000_000, 14_500_000), "destination.bytes": sorteio.randint(4_000, 9_000)})
        for indice in range(FLUXOS_DE_EXFILTRACAO)
    ]


def megabytes_exfiltrados(eventos_do_caso: List[Dict]) -> str:
    """A verdade do caso, somada sobre os fluxos que o próprio caso criou."""
    enviados = sum(documento["source"]["bytes"] for documento in eventos_do_caso
                   if documento.get("destination", {}).get("ip") == DESTINO_DA_EXFILTRACAO)
    return str(enviados // 1_000_000)


def eventos(ambiente: Ambiente, sorteio: random.Random) -> List[Dict]:
    return _infeccao() + _batimentos(sorteio) + _exfiltracao(sorteio)


ESTUDO = EstudoDeCaso(
    numero=2,
    titulo="O canal que respira",
    hipotese="Um implante que pede ordens a um servidor externo gera consultas regulares a um domínio que "
             "quase ninguém mais na empresa consulta.",
    perguntas=[
        Pergunta(chave="c2-dominio", caso=2, categoria="Comando e Controle", titulo="O Domínio Que Só Uma Máquina Conhece", nivel="Médio",
                 enunciado="Uma estação consulta um domínio externo com regularidade de relógio, e nenhuma outra "
                           "estação o consulta. Informe o domínio.",
                 dica="O domínio mais consultado da empresa é legítimo e aparece em todas as estações. Procure "
                      "o que tem muitas consultas vindas de uma única estação.",
                 resposta=DOMINIO_DO_CANAL,
                 busca='event.dataset:"dns"  →  agrupar dns.question.name com contagem única de host.name',
                 raciocinio="Frequência sozinha aponta a atualização da empresa; frequência com raridade de "
                            "estações aponta o canal."),
        Pergunta(chave="c2-estacao", caso=2, categoria="Comando e Controle", titulo="A Estação Que Chama", nivel="Fácil",
                 enunciado="Qual estação consulta o domínio do canal?",
                 dica="Filtre as consultas pelo domínio encontrado e leia host.name.",
                 resposta=ESTACAO,
                 busca='event.dataset:"dns" and dns.question.name:"telemetria-aurora-cdn.net"',
                 raciocinio="Um host só é o que se isola primeiro."),
        Pergunta(chave="c2-intervalo", caso=2, categoria="Comando e Controle", titulo="O Ritmo do Batimento", nivel="Difícil",
                 enunciado="De quanto em quanto tempo, em segundos, a estação consulta o domínio? Informe a "
                           "mediana dos intervalos entre consultas consecutivas, arredondada para a dezena.",
                 dica="Ordene as consultas por @timestamp e subtraia cada uma da anterior; o jitter é pequeno.",
                 resposta=str(INTERVALO_SEGUNDOS),
                 busca='event.dataset:"dns" and dns.question.name:"telemetria-aurora-cdn.net"  →  diferenças entre @timestamp',
                 raciocinio="Humano não navega a cada cinco minutos durante três dias, inclusive de madrugada."),
        Pergunta(chave="c2-executavel", caso=2, categoria="Evasão de Defesas", titulo="O Nome Emprestado", nivel="Médio",
                 enunciado="O processo que conversa com o servidor do canal tem nome de atualizador legítimo. "
                           "Informe o caminho completo do executável na estação infectada.",
                 dica="O mesmo nome existe em todas as estações, em Program Files. Na estação infectada, compare "
                      "process.executable e process.hash.sha256.",
                 resposta=EXECUTAVEL,
                 busca='event.dataset:"edr" and host.name:"WKS-ENG-117" and process.name:"OneDriveUpdater.exe"',
                 raciocinio="Mascaramento (T1036): o nome engana, o caminho e o hash não."),
        Pergunta(chave="c2-pai", caso=2, categoria="Execução", titulo="Quem Soltou o Implante", nivel="Médio",
                 enunciado="Qual processo iniciou o executável malicioso?",
                 dica="Leia process.parent.name no evento do executável fora de Program Files.",
                 resposta=PROCESSO_PAI,
                 busca='event.dataset:"edr" and process.executable:*AppData*',
                 raciocinio="Um atualizador filho do Word aponta para documento com macro como vetor inicial."),
        Pergunta(chave="c2-exfiltracao", caso=2, categoria="Exfiltração", titulo="O Destino do Volume", nivel="Difícil",
                 enunciado="Somando o que cada destino externo recebeu (bytes enviados pela origem), qual destino "
                           "recebeu mais dados da estação infectada?",
                 dica="Nenhum fluxo isolado chama atenção: some source.bytes por destination.ip. O maior fluxo "
                      "do período é o backup, que vai para um endereço interno.",
                 resposta=DESTINO_DA_EXFILTRACAO,
                 busca='event.dataset:"firewall" and host.name:"WKS-ENG-117" and not destination.ip:10.0.0.0/8  →  soma de source.bytes por destination.ip',
                 raciocinio="Exfiltração fatiada fica abaixo de qualquer limiar de fluxo; a soma a revela."),
        Pergunta(chave="c2-volume", caso=2, categoria="Exfiltração", titulo="Quanto Saiu", nivel="Difícil",
                 enunciado="Quantos megabytes (10^6 bytes), arredondados para baixo, a estação enviou ao destino "
                           "da exfiltração?",
                 dica="Some source.bytes dos fluxos da estação para o destino da exfiltração e divida por 1.000.000.",
                 resposta="",
                 busca='event.dataset:"firewall" and destination.ip:"198.51.100.61"  →  soma de source.bytes',
                 raciocinio="Dimensionar o vazamento é o que a resposta a incidentes precisa para notificar."),
    ],
)
