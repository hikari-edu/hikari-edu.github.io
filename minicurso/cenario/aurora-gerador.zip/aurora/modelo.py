"""O evento no formato que o Hikari indexa: ECS aninhado, com o conjunto em event.dataset."""

from datetime import datetime, timedelta, timezone
from typing import Any, Dict, List, Optional

# Um período fictício, longe de qualquer competição real.
INICIO_DO_PERIODO = datetime(2026, 3, 9, 0, 0, tzinfo=timezone.utc)
DIAS_DO_PERIODO = 3

SEVERIDADES = {0: "Informativo", 1: "Baixa", 2: "Média", 3: "Alta", 4: "Crítico"}


def aninhar(campos: Dict[str, Any]) -> Dict[str, Any]:
    """{"source.ip": "1.2.3.4"} vira {"source": {"ip": "1.2.3.4"}}."""
    documento: Dict[str, Any] = {}
    for caminho, valor in campos.items():
        partes = caminho.split(".")
        destino = documento
        for parte in partes[:-1]:
            destino = destino.setdefault(parte, {})
        destino[partes[-1]] = valor
    return documento


def carimbo(momento: datetime) -> str:
    return momento.astimezone(timezone.utc).isoformat(timespec="milliseconds").replace("+00:00", "Z")


def evento(conjunto: str, momento: datetime, acao: str, campos: Dict[str, Any],
           desfecho: str = "success", severidade: int = 0) -> Dict[str, Any]:
    documento = aninhar({
        "@timestamp": carimbo(momento),
        "event.dataset": conjunto,
        "event.action": acao,
        "event.outcome": desfecho,
        "event.severity": severidade,
        "event.severity_label": SEVERIDADES[severidade],
        **campos,
    })
    documento["message"] = acao
    return documento


def numerar(eventos: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    """Ordem cronológica e um identificador estável, como a importação grava."""
    ordenados = sorted(eventos, key=lambda documento: documento["@timestamp"])
    for indice, documento in enumerate(ordenados, start=1):
        documento["event"]["id"] = f"AUR-{indice:07d}"
    return ordenados


def momento(dia: int, hora: int, minuto: int = 0, segundo: int = 0,
            deslocamento: Optional[timedelta] = None) -> datetime:
    base = INICIO_DO_PERIODO + timedelta(days=dia, hours=hora, minutes=minuto, seconds=segundo)
    return base + (deslocamento or timedelta())
