"""Ponte para a Arena: alertas da Aurora exportados no formato do QRadar.

Na competição, os registros vêm de exportações do QRadar, com espaço no nome do
campo ("Source IP", "Event Name"). Os três casos do minicurso usam o formato ECS
(source.ip). Este quarto conjunto, pequeno e fictício, treina os mesmos gestos no
formato da prova: o valor mais frequente, um filtro em campo com espaço, o
primeiro no tempo e o mais raro. Nada aqui vem da competição.
"""

import random
from collections import Counter
from datetime import datetime, timedelta
from typing import Dict, List, Tuple

from .modelo import INICIO_DO_PERIODO, carimbo
from .perguntas import EstudoDeCaso, Pergunta

SEMENTE = 20261016
CONJUNTO = "qradar"
FONTES = ("FW-AURORA-01", "FW-AURORA-02", "IPS-AURORA-01")
INTERNOS = [f"10.40.{rede}.{host}" for rede in (0, 1, 2) for host in range(10, 60)]
EXTERNOS = [f"203.0.113.{host}" for host in range(100, 160)] + [f"192.0.2.{host}" for host in range(20, 60)]
CONTAS = ("a.souza", "b.martins", "c.moura", "d.lima", "e.rocha", "f.nunes", "g.pires", "h.matos")

ORIGEM_DA_FORCA_BRUTA = "198.51.100.23"
PRIMEIRA_CONTA_FORA_DE_HORA = "t.araujo"
ALERTA_COMUM = "Firewall Deny"
ALERTA_RARO = "Admin Account Created"

# Nome do alerta, categoria de baixo nível e quantas vezes aparece como ruído de fundo.
RUIDO = (
    (ALERTA_COMUM, "Firewall Deny", 900),
    ("Port Scan", "Network Sweep", 240),
    ("Malware Blocked", "Malware", 180),
    ("VPN Session Started", "Remote Access", 120),
    ("DNS Query to New Domain", "Suspicious Activity", 75),
)


def _momento(sorteio: random.Random) -> datetime:
    return INICIO_DO_PERIODO + timedelta(seconds=sorteio.randrange(3 * 24 * 3600))


def alerta(momento: datetime, nome: str, categoria: str, origem: str, destino: str, porta: int,
           conta: str = "N/A", magnitude: int = 3) -> Dict:
    return {
        "@timestamp": carimbo(momento),
        "event": {"dataset": CONJUNTO},
        "Start Time": momento.strftime("%Y-%m-%d %H:%M:%S"),
        "Event Name": nome,
        "Low Level Category": categoria,
        "Source IP": origem,
        "Destination IP": destino,
        "Destination Port": porta,
        "Username": conta,
        "Log Source": FONTES[porta % len(FONTES)],
        "Magnitude": magnitude,
    }


def _ruido(sorteio: random.Random) -> List[Dict]:
    eventos = []
    for nome, categoria, quantidade in RUIDO:
        for _ in range(quantidade):
            eventos.append(alerta(_momento(sorteio), nome, categoria, sorteio.choice(EXTERNOS + INTERNOS),
                                  sorteio.choice(INTERNOS), sorteio.choice((22, 53, 80, 443, 445, 3389)),
                                  sorteio.choice(CONTAS + ("N/A",)), sorteio.randint(1, 5)))
    return eventos


def _forca_bruta(sorteio: random.Random) -> List[Dict]:
    inicio = INICIO_DO_PERIODO + timedelta(days=1, hours=3)
    return [alerta(inicio + timedelta(seconds=40 * tentativa), "SSH Brute Force", "Brute Force Login",
                   ORIGEM_DA_FORCA_BRUTA, "10.40.0.21", 22, sorteio.choice(CONTAS), 7) for tentativa in range(60)]


def _fora_de_hora() -> List[Dict]:
    contas_e_horarios = ((PRIMEIRA_CONTA_FORA_DE_HORA, 1, 2, 12), ("e.rocha", 1, 23, 41),
                         ("b.martins", 2, 1, 5), ("h.matos", 2, 3, 30), ("d.lima", 2, 22, 58))
    return [alerta(INICIO_DO_PERIODO + timedelta(days=dia, hours=hora, minutes=minuto), "Login After Hours",
                   "User Login Success", "10.40.1.33", "10.40.0.5", 3389, conta, 5)
            for conta, dia, hora, minuto in contas_e_horarios]


def _raro() -> List[Dict]:
    return [alerta(INICIO_DO_PERIODO + timedelta(days=2, hours=4, minutes=7), ALERTA_RARO, "Account Created",
                   "10.40.1.33", "10.40.0.5", 445, "svc_relatorios", 8)]


def eventos(semente: int = SEMENTE) -> List[Dict]:
    sorteio = random.Random(semente)
    todos = _ruido(sorteio) + _forca_bruta(sorteio) + _fora_de_hora() + _raro()
    return sorted(todos, key=lambda documento: documento["@timestamp"])


def _com(eventos_: List[Dict], campo: str, valor: str) -> List[Dict]:
    return [documento for documento in eventos_ if documento.get(campo) == valor]


def conferir(eventos_: List[Dict]) -> Dict[str, Tuple[str, str]]:
    """Refaz cada resposta pelo caminho do caçador: chave → (obtido, esperado)."""
    nomes = Counter(documento["Event Name"] for documento in eventos_)
    forca_bruta = Counter(documento["Source IP"] for documento in _com(eventos_, "Event Name", "SSH Brute Force"))
    fora_de_hora = sorted(_com(eventos_, "Event Name", "Login After Hours"), key=lambda documento: documento["@timestamp"])
    unicos = [nome for nome, vezes in nomes.items() if vezes == 1]
    return {
        "p1-alerta-comum": (nomes.most_common(1)[0][0], ALERTA_COMUM),
        "p2-forca-bruta": (forca_bruta.most_common(1)[0][0] if len(forca_bruta) == 1 else "várias", ORIGEM_DA_FORCA_BRUTA),
        "p3-fora-de-hora": (fora_de_hora[0]["Username"], PRIMEIRA_CONTA_FORA_DE_HORA),
        "p4-alerta-raro": (unicos[0] if len(unicos) == 1 else "nenhum ou vários", ALERTA_RARO),
    }


def _pergunta(chave: str, categoria: str, titulo: str, enunciado: str, dica: str, resposta: str,
              busca: str, raciocinio: str) -> Pergunta:
    return Pergunta(chave=chave, caso=4, categoria=categoria, titulo=titulo, enunciado=enunciado, dica=dica,
                    resposta=resposta, nivel="Fácil", busca=busca, raciocinio=raciocinio)


ESTUDO = EstudoDeCaso(
    numero=4, titulo="Ponte para a Arena",
    hipotese="Os mesmos gestos valem em outro formato de registro: filtrar, contar, ordenar pelo tempo e "
             "tirar o comum da frente.",
    perguntas=[
        _pergunta("p1-alerta-comum", "Triagem e Métricas", "O Alerta Mais Comum",
                  "Os alertas da Aurora também chegam exportados do QRadar, com espaço no nome dos campos. "
                  "Qual nome de alerta (campo Event Name) aparece mais vezes?",
                  'Busque event.dataset:"qradar" e clique no campo Event Name: o primeiro da lista é o mais frequente.',
                  ALERTA_COMUM, 'event.dataset:"qradar" → valores mais frequentes de Event Name',
                  "Num formato novo, o primeiro passo é o mesmo: ver o que domina o volume."),
        _pergunta("p2-forca-bruta", "Acesso a Credenciais", "De Onde Veio a Força Bruta",
                  "Qual endereço de origem (campo Source IP) disparou os alertas SSH Brute Force?",
                  'Campo com espaço no nome vai entre aspas: "Event Name":"SSH Brute Force". Depois, clique em Source IP.',
                  ORIGEM_DA_FORCA_BRUTA, '"Event Name":"SSH Brute Force" → valores de Source IP',
                  "Filtrar num campo com espaço só exige as aspas no nome do campo; o resto da busca é igual."),
        _pergunta("p3-fora-de-hora", "Acesso Inicial", "Quem Entrou Primeiro Fora de Hora",
                  "Entre os alertas Login After Hours, qual conta (campo Username) aparece primeiro no tempo?",
                  'Filtre "Event Name":"Login After Hours" e clique no título da coluna @timestamp para ordenar '
                  "do mais antigo para o mais novo.",
                  PRIMEIRA_CONTA_FORA_DE_HORA, '"Event Name":"Login After Hours" → ordenar por @timestamp, crescente',
                  "O Discover mostra primeiro o evento mais novo; a pergunta pelo primeiro pede inverter a ordem."),
        _pergunta("p4-alerta-raro", "Persistência", "O Alerta Que Só Aconteceu Uma Vez",
                  "Qual nome de alerta aparece uma única vez em todo o período?",
                  'Tire os alertas comuns da frente: event.dataset:"qradar" and not "Event Name":"Firewall Deny", '
                  "e acrescente um not para cada alerta comum até sobrar o raro.",
                  ALERTA_RARO, 'event.dataset:"qradar" and not "Event Name":(…comuns) → o que sobra',
                  "A lista dos mais frequentes esconde o raro; excluir o comum, um por vez, faz o raro aparecer."),
    ])
