"""Estudo de caso 3 — Do mapa do diretório ao impacto.

Com uma conta administrativa de backup, alguém enumera dezenas de grupos do
Active Directory em poucos minutos a partir de uma estação da administração.
Meia hora depois, a mesma conta instala um serviço remoto no servidor de
arquivos, apaga as cópias de sombra e renomeia milhares de arquivos. A isca é
o inventário, que gera muito mais eventos de enumeração que o ataque, sempre
nos mesmos três grupos; e o agente de backup, que também renomeia arquivos em
massa, só que toda madrugada.
"""

import random
from datetime import timedelta
from typing import Dict, List

from .ambiente import Ambiente
from .modelo import evento, momento
from .perguntas import EstudoDeCaso, Pergunta

CONTA_ADMINISTRATIVA = "adm.backup"
ESTACAO_IP = "10.40.0.140"
ESTACAO = "WKS-ADM-104"
CONTROLADOR = "DC01"
PRIMEIRO_SERVIDOR = "FS01"
SEGUNDO_SERVIDOR = "FS02"
PROCESSO_DE_CIFRA = "aurora_upd.exe"
COMANDO_DAS_SOMBRAS = "vssadmin delete shadows /all /quiet"
EXTENSAO = "aurora-lock"
ARQUIVOS_POR_SERVIDOR = {PRIMEIRO_SERVIDOR: 2140, SEGUNDO_SERVIDOR: 1280}
ENUMERACAO = momento(1, 16, 40)
MOVIMENTO_LATERAL = momento(1, 17, 5)
GRUPOS = ["Domain Admins", "Enterprise Admins", "Schema Admins", "Administrators", "Account Operators",
          "Backup Operators", "Server Operators", "Print Operators", "Remote Desktop Users",
          "Remote Management Users", "DnsAdmins", "Group Policy Creator Owners", "Cert Publishers",
          "Protected Users", "Key Admins", "Enterprise Key Admins", "Cloneable Domain Controllers",
          "Read-only Domain Controllers", "Domain Controllers", "Domain Computers", "Domain Users",
          "Domain Guests", "Hyper-V Administrators", "Access Control Assistance Operators",
          "Storage Replica Administrators", "Event Log Readers", "Distributed COM Users",
          "Performance Log Users", "Performance Monitor Users", "Network Configuration Operators",
          "Cryptographic Operators", "Incoming Forest Trust Builders", "Windows Authorization Access Group",
          "Terminal Server License Servers", "Pre-Windows 2000 Compatible Access", "RAS and IAS Servers",
          "Aurora-TI-Infra", "Aurora-TI-Seguranca", "Aurora-Financeiro", "Aurora-Diretoria",
          "Aurora-NOC", "Aurora-Backup", "Aurora-VPN-Usuarios", "Aurora-ERP-Admins", "Aurora-DBA",
          "Aurora-Servidores-Arquivos", "Aurora-Terceiros"]


def _enumeracao(sorteio: random.Random) -> List[Dict]:
    # Ferramentas de enumeração repetem consultas aos grupos mais valiosos.
    consultas = GRUPOS + sorteio.sample(GRUPOS[:20], 14)
    return [
        evento("auth", ENUMERACAO + timedelta(seconds=indice * 6 + sorteio.randint(0, 3)),
               "Associação de grupo enumerada",
               {"user.name": CONTA_ADMINISTRATIVA, "host.name": CONTROLADOR, "source.ip": ESTACAO_IP,
                "group.name": grupo, "event.code": "4799"}, severidade=2)
        for indice, grupo in enumerate(consultas)
    ]


def _estacao_de_origem() -> List[Dict]:
    return [evento("auth", ENUMERACAO - timedelta(minutes=12), "Logon interativo concluído",
                   {"user.name": CONTA_ADMINISTRATIVA, "host.name": ESTACAO, "host.ip": ESTACAO_IP,
                    "source.ip": ESTACAO_IP, "event.code": "4624", "winlog.logon.type": "2"})]


def _no_servidor(servidor: str, inicio) -> List[Dict]:
    base = {"host.name": servidor, "user.name": CONTA_ADMINISTRATIVA}
    return [
        evento("auth", inicio, "Logon de rede concluído",
               {**base, "source.ip": ESTACAO_IP, "event.code": "4624", "winlog.logon.type": "3"}),
        evento("edr", inicio + timedelta(seconds=9), "Serviço instalado",
               {**base, "service.name": "PSEXESVC", "process.name": "services.exe",
                "process.executable": r"C:\Windows\System32\services.exe"}, severidade=3),
        evento("edr", inicio + timedelta(seconds=14), "Processo iniciado",
               {**base, "process.name": PROCESSO_DE_CIFRA, "process.parent.name": "PSEXESVC.exe",
                "process.executable": rf"C:\Windows\Temp\{PROCESSO_DE_CIFRA}"}, severidade=3),
        evento("edr", inicio + timedelta(seconds=31), "Cópias de sombra excluídas",
               {**base, "process.name": "vssadmin.exe", "process.parent.name": PROCESSO_DE_CIFRA,
                "process.command_line": COMANDO_DAS_SOMBRAS}, severidade=4),
    ]


def _cifragem(servidor: str, inicio, sorteio: random.Random) -> List[Dict]:
    pastas = ["Financeiro", "Contratos", "Engenharia", "RH", "Diretoria", "Comercial"]
    return [
        evento("fileserver", inicio + timedelta(seconds=45 + indice * 0.7), "Arquivo renomeado",
               {"host.name": servidor, "user.name": CONTA_ADMINISTRATIVA, "process.name": PROCESSO_DE_CIFRA,
                "file.path": rf"D:\Compartilhado\{sorteio.choice(pastas)}\doc_{indice:05d}.xlsx.{EXTENSAO}",
                "file.extension": EXTENSAO}, severidade=4)
        for indice in range(ARQUIVOS_POR_SERVIDOR[servidor])
    ]


def eventos(ambiente: Ambiente, sorteio: random.Random) -> List[Dict]:
    segundo = MOVIMENTO_LATERAL + timedelta(minutes=9)
    return (_estacao_de_origem() + _enumeracao(sorteio)
            + _no_servidor(PRIMEIRO_SERVIDOR, MOVIMENTO_LATERAL) + _cifragem(PRIMEIRO_SERVIDOR, MOVIMENTO_LATERAL, sorteio)
            + _no_servidor(SEGUNDO_SERVIDOR, segundo) + _cifragem(SEGUNDO_SERVIDOR, segundo, sorteio))


ESTUDO = EstudoDeCaso(
    numero=3,
    titulo="Do mapa do diretório ao impacto",
    hipotese="Antes de cifrar, quem invade um domínio precisa saber quem administra o quê: uma rajada de "
             "enumeração de grupos fora da rotina de inventário precede o movimento lateral.",
    perguntas=[
        Pergunta(chave="c3-conta", caso=3, categoria="Descoberta", titulo="Quem Mapeou o Diretório", nivel="Médio",
                 enunciado="O controlador de domínio registrou enumeração de associação de grupos (evento 4799). "
                           "Além da rotina de inventário, uma conta enumerou dezenas de grupos. Qual?",
                 dica="A conta com mais eventos de enumeração é o inventário, que confere sempre os mesmos três "
                      "grupos. Conte grupos distintos por conta, e não eventos.",
                 resposta=CONTA_ADMINISTRATIVA,
                 busca='event.dataset:"auth" and event.code:"4799"  →  agrupar user.name por contagem única de group.name',
                 raciocinio="A rotina legítima também gera 4799; a diferença é a amplitude e o horário."),
        Pergunta(chave="c3-grupos", caso=3, categoria="Descoberta", titulo="A Amplitude do Mapa", nivel="Fácil",
                 enunciado="Quantos grupos distintos essa conta enumerou?",
                 dica="Algumas consultas se repetem: conte valores distintos de group.name.",
                 resposta=str(len(GRUPOS)),
                 busca='event.dataset:"auth" and event.code:"4799" and user.name:"adm.backup"  →  contagem única de group.name',
                 raciocinio="Contar eventos superestima; contar grupos mede o reconhecimento."),
        Pergunta(chave="c3-estacao", caso=3, categoria="Descoberta", titulo="De Onde Partiu", nivel="Difícil",
                 enunciado="Os eventos de enumeração só trazem o endereço de origem. Qual o nome da estação "
                           "que usa esse endereço?",
                 dica="Leia source.ip nos eventos 4799 da conta e procure o mesmo endereço em host.ip nos logons "
                      "interativos.",
                 resposta=ESTACAO,
                 busca='event.dataset:"auth" and host.ip:"10.40.0.140" and winlog.logon.type:"2"',
                 raciocinio="Pivotar de endereço para nome é o que transforma um IP numa máquina para isolar."),
        Pergunta(chave="c3-primeiro", caso=3, categoria="Impacto", titulo="O Primeiro Servidor Atingido", nivel="Médio",
                 enunciado="Arquivos passaram a ganhar uma extensão estranha em mais de um servidor. Em qual "
                           "servidor isso começou?",
                 dica="Filtre os arquivos renomeados com a extensão nova e ordene por @timestamp.",
                 resposta=PRIMEIRO_SERVIDOR,
                 busca=f'event.dataset:"fileserver" and file.extension:"{EXTENSAO}"  →  ordenar por @timestamp',
                 raciocinio="O primeiro servidor guarda os artefatos do início; é por ele que a análise forense começa."),
        Pergunta(chave="c3-processo", caso=3, categoria="Impacto", titulo="O Processo Que Renomeia", nivel="Fácil",
                 enunciado="Qual processo renomeou os arquivos para a extensão nova?",
                 dica="O agente de backup renomeia em massa toda madrugada. Olhe só os arquivos com a extensão nova.",
                 resposta=PROCESSO_DE_CIFRA,
                 busca=f'event.dataset:"fileserver" and file.extension:"{EXTENSAO}"  →  agrupar process.name',
                 raciocinio="Renomear em massa não é crime; renomear para uma extensão nova, às 17h, é."),
        Pergunta(chave="c3-sombras", caso=3, categoria="Evasão de Defesas", titulo="Sem Volta Atrás", nivel="Médio",
                 enunciado="Antes de renomear, o processo apagou as cópias de sombra. Informe a linha de comando "
                           "exatamente como registrada.",
                 dica="Procure no EDR os processos filhos do processo de cifra e leia process.command_line.",
                 resposta=COMANDO_DAS_SOMBRAS,
                 busca=f'event.dataset:"edr" and process.parent.name:"{PROCESSO_DE_CIFRA}"',
                 raciocinio="Inibir a recuperação (T1490) é assinatura de ransomware, anterior à cifra."),
        Pergunta(chave="c3-arquivos", caso=3, categoria="Impacto", titulo="O Tamanho do Estrago", nivel="Médio",
                 enunciado="Quantos arquivos ganharam a extensão nova, somando todos os servidores?",
                 dica="Conte os eventos de renomeação com a extensão nova, sem filtrar por servidor.",
                 resposta=str(sum(ARQUIVOS_POR_SERVIDOR.values())),
                 busca=f'event.dataset:"fileserver" and file.extension:"{EXTENSAO}"  →  contagem',
                 raciocinio="O número orienta a restauração e a comunicação do incidente."),
    ],
)
