"""O que cada estudo de caso pergunta, e o caminho que o caçador percorre até a resposta."""

from typing import List

from pydantic import BaseModel


class Pergunta(BaseModel):
    chave: str
    caso: int
    # Tática do ATT&CK, no vocabulário que a plataforma usa para ordenar os desafios.
    categoria: str
    titulo: str
    enunciado: str
    dica: str
    resposta: str
    nivel: str
    busca: str
    raciocinio: str

    @property
    def valor(self) -> int:
        return {"Fácil": 100, "Médio": 200, "Difícil": 300}[self.nivel]


class EstudoDeCaso(BaseModel):
    numero: int
    titulo: str
    hipotese: str
    perguntas: List[Pergunta]
