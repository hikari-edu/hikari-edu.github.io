"""Refaz, sobre todos os eventos, o caminho que cada pergunta descreve.

A resposta declarada pelo caso nunca é usada como prova: cada pergunta tem aqui
uma busca própria, escrita como o caçador a faria no Kibana, e o gabarito só
vale se as duas coincidirem. As iscas também são conferidas: o caminho ingênuo
precisa levar a outra resposta, ou o estudo de caso não ensina nada.
"""

from collections import Counter, defaultdict
from datetime import datetime
from statistics import median
from typing import Callable, Dict, Iterable, List, Optional, Tuple

from pydantic import BaseModel


def campo(documento: Dict, caminho: str):
    valor = documento
    for parte in caminho.split("."):
        if not isinstance(valor, dict) or parte not in valor:
            return None
        valor = valor[parte]
    return valor


def filtrar(eventos: Iterable[Dict], **criterios) -> List[Dict]:
    return [documento for documento in eventos
            if all(campo(documento, chave.replace("__", ".")) == valor for chave, valor in criterios.items())]


def topo(contagem: Dict[str, int]) -> Tuple[str, bool]:
    """O primeiro colocado e se ele está sozinho no topo."""
    ordenado = sorted(contagem.items(), key=lambda item: -item[1])
    return ordenado[0][0], len(ordenado) == 1 or ordenado[0][1] > ordenado[1][1]


def distintos_por(eventos: Iterable[Dict], chave: str, valor: str) -> Dict[str, int]:
    conjuntos = defaultdict(set)
    for documento in eventos:
        conjuntos[campo(documento, chave)].add(campo(documento, valor))
    return {grupo: len(itens) for grupo, itens in conjuntos.items()}


def soma_por(eventos: Iterable[Dict], chave: str, valor: str) -> Dict[str, int]:
    somas = Counter()
    for documento in eventos:
        somas[campo(documento, chave)] += campo(documento, valor)
    return dict(somas)


def contagem_por(eventos: Iterable[Dict], chave: str) -> Dict[str, int]:
    return dict(Counter(campo(documento, chave) for documento in eventos))


def instante(documento: Dict) -> datetime:
    return datetime.fromisoformat(documento["@timestamp"].replace("Z", "+00:00"))


def externo(ip: str) -> bool:
    return not ip.startswith("10.")


class Resultado(BaseModel):
    chave: str
    esperado: str
    obtido: Optional[str]
    unico: bool

    @property
    def confere(self) -> bool:
        return self.unico and self.obtido == self.esperado


# ------------------------------------------------------------------ caso 1
def origem_que_entrou(eventos: List[Dict]) -> Tuple[str, bool]:
    falhas = filtrar(eventos, event__dataset="vpn", event__outcome="failure")
    contas_por_origem = distintos_por(falhas, "source.ip", "user.name")
    com_sucesso = {campo(d, "source.ip") for d in filtrar(eventos, event__dataset="vpn", event__outcome="success")}
    candidatas = {ip: contas for ip, contas in contas_por_origem.items() if ip in com_sucesso}
    return topo(candidatas)


def contas_tentadas(eventos: List[Dict]) -> Tuple[str, bool]:
    origem, _ = origem_que_entrou(eventos)
    return str(len({campo(d, "user.name") for d in filtrar(eventos, event__dataset="vpn", source__ip=origem)})), True


def conta_que_cedeu(eventos: List[Dict]) -> Tuple[str, bool]:
    origem, _ = origem_que_entrou(eventos)
    return topo(contagem_por(filtrar(eventos, event__dataset="vpn", source__ip=origem, event__outcome="success"),
                             "user.name"))


def minuto_zero(eventos: List[Dict]) -> Tuple[str, bool]:
    origem, _ = origem_que_entrou(eventos)
    sessoes = filtrar(eventos, event__dataset="vpn", source__ip=origem, event__action="Sessão VPN estabelecida")
    return sessoes[0]["@timestamp"], len(sessoes) == 1


def servidor_do_rdp(eventos: List[Dict]) -> Tuple[str, bool]:
    origem, _ = origem_que_entrou(eventos)
    sessao = filtrar(eventos, event__dataset="vpn", source__ip=origem, event__action="Sessão VPN estabelecida")[0]
    remotos = filtrar(eventos, event__dataset="auth", source__ip=campo(sessao, "client.nat.ip"),
                      winlog__logon__type="10")
    return topo(contagem_por(remotos, "host.name"))


def novo_administrador(eventos: List[Dict]) -> Tuple[str, bool]:
    servidor, _ = servidor_do_rdp(eventos)
    adicoes = filtrar(eventos, event__dataset="auth", host__name=servidor, event__code="4732")
    return topo(contagem_por(adicoes, "target.user.name"))


def isca_das_falhas(eventos: List[Dict]) -> Tuple[str, bool]:
    """O caminho ingênuo: a origem com mais falhas. Precisa ser outra."""
    return topo(contagem_por(filtrar(eventos, event__dataset="vpn", event__outcome="failure"), "source.ip"))


# ------------------------------------------------------------------ caso 2
def dominio_raro_e_frequente(eventos: List[Dict]) -> Tuple[str, bool]:
    consultas = filtrar(eventos, event__dataset="dns")
    estacoes = distintos_por(consultas, "dns.question.name", "host.name")
    volume = contagem_por(consultas, "dns.question.name")
    de_uma_estacao = {dominio: volume[dominio] for dominio, quantas in estacoes.items() if quantas == 1}
    return topo(de_uma_estacao)


def estacao_do_canal(eventos: List[Dict]) -> Tuple[str, bool]:
    dominio, _ = dominio_raro_e_frequente(eventos)
    return topo(contagem_por(filtrar(eventos, event__dataset="dns", dns__question__name=dominio), "host.name"))


def ritmo(eventos: List[Dict]) -> Tuple[str, bool]:
    dominio, _ = dominio_raro_e_frequente(eventos)
    momentos = sorted(instante(d) for d in filtrar(eventos, event__dataset="dns", dns__question__name=dominio))
    intervalos = [(depois - antes).total_seconds() for antes, depois in zip(momentos, momentos[1:])]
    return str(int(round(median(intervalos), -1))), True


def executavel_mascarado(eventos: List[Dict]) -> Tuple[str, bool]:
    estacao, _ = estacao_do_canal(eventos)
    iniciados = filtrar(eventos, event__dataset="edr", host__name=estacao, process__name="OneDriveUpdater.exe")
    fora_do_padrao = {campo(d, "process.executable") for d in iniciados} - {
        campo(d, "process.executable") for d in filtrar(eventos, event__dataset="edr", process__name="OneDriveUpdater.exe")
        if campo(d, "host.name") != estacao}
    return (next(iter(fora_do_padrao)), True) if len(fora_do_padrao) == 1 else (None, False)


def pai_do_implante(eventos: List[Dict]) -> Tuple[str, bool]:
    executavel, _ = executavel_mascarado(eventos)
    return topo(contagem_por(filtrar(eventos, event__dataset="edr", process__executable=executavel),
                             "process.parent.name"))


def destino_do_volume(eventos: List[Dict]) -> Tuple[str, bool]:
    estacao, _ = estacao_do_canal(eventos)
    fluxos = [d for d in filtrar(eventos, event__dataset="firewall", host__name=estacao)
              if externo(campo(d, "destination.ip"))]
    return topo(soma_por(fluxos, "destination.ip", "source.bytes"))


def megabytes(eventos: List[Dict]) -> Tuple[str, bool]:
    estacao, _ = estacao_do_canal(eventos)
    destino, _ = destino_do_volume(eventos)
    fluxos = filtrar(eventos, event__dataset="firewall", host__name=estacao, destination__ip=destino)
    return str(sum(campo(d, "source.bytes") for d in fluxos) // 1_000_000), True


def isca_do_dominio(eventos: List[Dict]) -> Tuple[str, bool]:
    return topo(contagem_por(filtrar(eventos, event__dataset="dns"), "dns.question.name"))


def isca_do_maior_fluxo(eventos: List[Dict]) -> Tuple[str, bool]:
    maior = max(filtrar(eventos, event__dataset="firewall"), key=lambda d: campo(d, "source.bytes"))
    return campo(maior, "destination.ip"), True


# ------------------------------------------------------------------ caso 3
def conta_do_mapa(eventos: List[Dict]) -> Tuple[str, bool]:
    return topo(distintos_por(filtrar(eventos, event__dataset="auth", event__code="4799"), "user.name", "group.name"))


def grupos_mapeados(eventos: List[Dict]) -> Tuple[str, bool]:
    conta, _ = conta_do_mapa(eventos)
    consultas = filtrar(eventos, event__dataset="auth", event__code="4799", user__name=conta)
    return str(len({campo(d, "group.name") for d in consultas})), True


def estacao_de_origem(eventos: List[Dict]) -> Tuple[str, bool]:
    conta, _ = conta_do_mapa(eventos)
    origem, _ = topo(contagem_por(filtrar(eventos, event__dataset="auth", event__code="4799", user__name=conta),
                                  "source.ip"))
    interativos = filtrar(eventos, event__dataset="auth", host__ip=origem, winlog__logon__type="2")
    return topo(contagem_por(interativos, "host.name"))


def extensao_nova(eventos: List[Dict]) -> List[Dict]:
    renomeados = filtrar(eventos, event__dataset="fileserver", event__action="Arquivo renomeado")
    rotineiras = {campo(d, "file.extension") for d in renomeados if instante(d).hour < 6}
    return [d for d in renomeados if campo(d, "file.extension") not in rotineiras]


def primeiro_servidor(eventos: List[Dict]) -> Tuple[str, bool]:
    atingidos = sorted(extensao_nova(eventos), key=instante)
    return campo(atingidos[0], "host.name"), True


def processo_da_cifra(eventos: List[Dict]) -> Tuple[str, bool]:
    return topo(contagem_por(extensao_nova(eventos), "process.name"))


def comando_das_sombras(eventos: List[Dict]) -> Tuple[str, bool]:
    processo, _ = processo_da_cifra(eventos)
    return topo(contagem_por(filtrar(eventos, event__dataset="edr", process__parent__name=processo),
                             "process.command_line"))


def arquivos_atingidos(eventos: List[Dict]) -> Tuple[str, bool]:
    # O mesmo caminho em dois servidores são dois arquivos.
    return str(len({(campo(d, "host.name"), campo(d, "file.path")) for d in extensao_nova(eventos)})), True


def isca_da_enumeracao(eventos: List[Dict]) -> Tuple[str, bool]:
    """O caminho ingênuo: a conta com mais eventos 4799. Precisa ser a do inventário."""
    return topo(contagem_por(filtrar(eventos, event__dataset="auth", event__code="4799"), "user.name"))


CAMINHOS: Dict[str, Callable[[List[Dict]], Tuple[Optional[str], bool]]] = {
    "c1-origem": origem_que_entrou, "c1-contas": contas_tentadas, "c1-conta": conta_que_cedeu,
    "c1-instante": minuto_zero, "c1-servidor": servidor_do_rdp, "c1-persistencia": novo_administrador,
    "c2-dominio": dominio_raro_e_frequente, "c2-estacao": estacao_do_canal, "c2-intervalo": ritmo,
    "c2-executavel": executavel_mascarado, "c2-pai": pai_do_implante, "c2-exfiltracao": destino_do_volume,
    "c2-volume": megabytes,
    "c3-conta": conta_do_mapa, "c3-grupos": grupos_mapeados, "c3-estacao": estacao_de_origem,
    "c3-primeiro": primeiro_servidor, "c3-processo": processo_da_cifra, "c3-sombras": comando_das_sombras,
    "c3-arquivos": arquivos_atingidos,
}

ISCAS: Dict[str, Tuple[Callable, str]] = {
    "c1-origem": (isca_das_falhas, "a origem com mais falhas"),
    "c2-dominio": (isca_do_dominio, "o domínio mais consultado"),
    "c2-exfiltracao": (isca_do_maior_fluxo, "o destino do maior fluxo isolado"),
    "c3-conta": (isca_da_enumeracao, "a conta com mais eventos de enumeração"),
}


def conferir(eventos: List[Dict], perguntas) -> List[Resultado]:
    resultados = []
    for pergunta in perguntas:
        obtido, unico = CAMINHOS[pergunta.chave](eventos)
        resultados.append(Resultado(chave=pergunta.chave, esperado=pergunta.resposta, obtido=obtido, unico=unico))
    return resultados


def iscas_que_enganam(eventos: List[Dict], perguntas) -> Dict[str, bool]:
    """Para cada isca, se o caminho ingênuo leva a uma resposta diferente da certa."""
    respostas = {pergunta.chave: pergunta.resposta for pergunta in perguntas}
    return {chave: funcao(eventos)[0] != respostas[chave] for chave, (funcao, _) in ISCAS.items()}
