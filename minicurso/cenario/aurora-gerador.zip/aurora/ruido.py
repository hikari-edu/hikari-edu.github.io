"""O dia a dia da Aurora Telecom: o fundo contra o qual cada ataque precisa ser achado.

Algumas rotinas legítimas foram escolhidas por parecerem suspeitas a quem olha
só o topo de uma contagem: a sonda de monitoramento que erra a senha da VPN o
dia inteiro, a atualização que toda estação consulta de hora em hora, o backup
que manda fluxos de gigabytes, o inventário que enumera grupos do diretório a
cada dez minutos.
São elas que obrigam a caçada a formular hipóteses, e não só a ordenar tabelas.
"""

import random
from datetime import timedelta
from typing import Dict, Iterator, List

from .ambiente import Ambiente, Pessoa
from .modelo import DIAS_DO_PERIODO, evento, momento

SONDA_IP = "10.20.5.14"
SONDA_CONTA = "monitor.vpn"
DOMINIOS_COMUNS = ["www.google.com", "outlook.office365.com", "teams.microsoft.com", "login.microsoftonline.com",
                   "www.aurora.com.br", "intranet.aurora.com.br", "github.com", "cdn.jsdelivr.net",
                   "www.youtube.com", "api.whatsapp.com", "portal.anatel.gov.br", "www.gov.br"]
DOMINIO_DE_ATUALIZACAO = "update.aurora.com.br"
DESTINOS_COMUNS = ["142.250.79.36", "52.97.146.162", "13.107.42.14", "20.190.160.2", "140.82.121.4"]
ESPELHO_DE_ATUALIZACAO = "203.0.113.200"
SERVIDOR_DE_BACKUP = "SRV-MGMT-01"
DESTINO_DO_BACKUP = "10.30.0.10"
ONEDRIVE_LEGITIMO = r"C:\Program Files\Microsoft OneDrive\OneDriveUpdater.exe"
HASH_ONEDRIVE_LEGITIMO = "6a1f0c2e9b7d44c3a8e5f1d2b3c4a5e6f7081920a1b2c3d4e5f60718293a4b5c"
PROCESSOS_COMUNS = [("chrome.exe", r"C:\Program Files\Google\Chrome\Application\chrome.exe", "explorer.exe"),
                    ("OUTLOOK.EXE", r"C:\Program Files\Microsoft Office\root\Office16\OUTLOOK.EXE", "explorer.exe"),
                    ("ms-teams.exe", r"C:\Program Files\WindowsApps\MSTeams\ms-teams.exe", "explorer.exe"),
                    ("WINWORD.EXE", r"C:\Program Files\Microsoft Office\root\Office16\WINWORD.EXE", "explorer.exe")]
GRUPOS_DO_INVENTARIO = ["Domain Users", "Aurora-Colaboradores", "Aurora-Impressoras"]


def _ip_residencial(pessoa: Pessoa) -> str:
    semente = sum(ord(letra) for letra in pessoa.conta)
    return f"177.{20 + semente % 40}.{semente % 250}.{(semente * 7) % 250 + 1}"


def vpn_do_expediente(ambiente: Ambiente, sorteio: random.Random) -> Iterator[Dict]:
    for dia in range(DIAS_DO_PERIODO):
        for indice, pessoa in enumerate(ambiente.pessoas):
            if sorteio.random() > 0.7:
                continue
            entrada = momento(dia, 11, sorteio.randint(0, 59), sorteio.randint(0, 59))
            origem = {"source.ip": _ip_residencial(pessoa), "source.geo.country_iso_code": "BR",
                      "user.name": pessoa.conta, "host.name": "VPN-GW-01"}
            if sorteio.random() < 0.05:
                yield evento("vpn", entrada - timedelta(seconds=40), "Autenticação VPN falhou", origem,
                             desfecho="failure", severidade=1)
            yield evento("vpn", entrada, "Sessão VPN estabelecida",
                         {**origem, "client.nat.ip": f"10.8.{1 + indice // 250}.{10 + indice % 240}"})
            yield evento("vpn", entrada + timedelta(hours=sorteio.randint(2, 8)), "Túnel VPN encerrado", origem)


def sonda_mal_configurada() -> Iterator[Dict]:
    """A sonda que testa a VPN com uma senha vencida: muitas falhas, uma conta só, nenhum sucesso."""
    for minuto in range(0, DIAS_DO_PERIODO * 24 * 60, 3):
        yield evento("vpn", momento(0, 0, minuto, 7), "Autenticação VPN falhou",
                     {"source.ip": SONDA_IP, "user.name": SONDA_CONTA, "host.name": "VPN-GW-01"},
                     desfecho="failure", severidade=1)


def logons(ambiente: Ambiente, sorteio: random.Random) -> Iterator[Dict]:
    for dia in range(DIAS_DO_PERIODO):
        for pessoa in ambiente.pessoas:
            chegada = momento(dia, 11, sorteio.randint(0, 50))
            yield evento("auth", chegada, "Logon interativo concluído",
                         {"user.name": pessoa.conta, "host.name": pessoa.estacao, "host.ip": pessoa.ip,
                          "source.ip": pessoa.ip, "event.code": "4624", "winlog.logon.type": "2"})
            for _ in range(sorteio.randint(1, 3)):
                servidor = sorteio.choice(ambiente.servidores_de_arquivos)
                yield evento("auth", chegada + timedelta(minutes=sorteio.randint(5, 420)), "Logon de rede concluído",
                             {"user.name": pessoa.conta, "host.name": servidor, "source.ip": pessoa.ip,
                              "event.code": "4624", "winlog.logon.type": "3"})


def inventario_do_diretorio() -> Iterator[Dict]:
    """A ferramenta de inventário confere os mesmos três grupos a cada dez minutos, o período inteiro."""
    for rodada in range(DIAS_DO_PERIODO * 24 * 6):
        for ordem, grupo in enumerate(GRUPOS_DO_INVENTARIO):
            yield evento("auth", momento(0, 0, rodada * 10, 10 + ordem), "Associação de grupo enumerada",
                         {"user.name": "svc_inventario", "host.name": "DC01", "source.ip": "10.30.0.21",
                          "group.name": grupo, "event.code": "4799"})


def resolucoes(ambiente: Ambiente, sorteio: random.Random) -> Iterator[Dict]:
    for pessoa in ambiente.pessoas:
        for hora in range(DIAS_DO_PERIODO * 24):
            yield evento("dns", momento(0, hora, sorteio.randint(0, 59), sorteio.randint(0, 59)),
                         "Consulta DNS resolvida",
                         {"dns.question.name": DOMINIO_DE_ATUALIZACAO, "source.ip": pessoa.ip,
                          "host.name": pessoa.estacao, "dns.question.type": "A"})
        for dia in range(DIAS_DO_PERIODO):
            for _ in range(sorteio.randint(25, 45)):
                yield evento("dns", momento(dia, sorteio.randint(11, 21), sorteio.randint(0, 59), sorteio.randint(0, 59)),
                             "Consulta DNS resolvida",
                             {"dns.question.name": sorteio.choice(DOMINIOS_COMUNS), "source.ip": pessoa.ip,
                              "host.name": pessoa.estacao, "dns.question.type": "A"})
    for dominio in ("fornecedor-cabos.com.br", "catalogo-antenas.net", "cotacao-fibra.com"):
        pessoa = sorteio.choice(ambiente.pessoas)
        for vez in range(3):
            yield evento("dns", momento(1, 15, 10 + vez * 7), "Consulta DNS resolvida",
                         {"dns.question.name": dominio, "source.ip": pessoa.ip, "host.name": pessoa.estacao,
                          "dns.question.type": "A"})


def fluxos(ambiente: Ambiente, sorteio: random.Random) -> Iterator[Dict]:
    for dia in range(DIAS_DO_PERIODO):
        for pessoa in ambiente.pessoas:
            for _ in range(sorteio.randint(18, 30)):
                yield evento("firewall", momento(dia, sorteio.randint(11, 21), sorteio.randint(0, 59), sorteio.randint(0, 59)),
                             "Conexão permitida",
                             {"source.ip": pessoa.ip, "host.name": pessoa.estacao,
                              "destination.ip": sorteio.choice(DESTINOS_COMUNS), "destination.port": 443,
                              "network.transport": "tcp", "source.bytes": sorteio.randint(2_000, 90_000),
                              "destination.bytes": sorteio.randint(20_000, 4_000_000)})
            if sorteio.random() < 0.3:
                yield evento("firewall", momento(dia, 12, sorteio.randint(0, 59)), "Conexão permitida",
                             {"source.ip": pessoa.ip, "host.name": pessoa.estacao,
                              "destination.ip": ESPELHO_DE_ATUALIZACAO, "destination.port": 443,
                              "network.transport": "tcp", "source.bytes": sorteio.randint(3_000, 9_000),
                              "destination.bytes": sorteio.randint(50_000_000, 400_000_000)})
        for lote in range(6):
            yield evento("firewall", momento(dia, 3, lote * 10), "Conexão permitida",
                         {"source.ip": "10.30.0.5", "host.name": SERVIDOR_DE_BACKUP,
                          "destination.ip": DESTINO_DO_BACKUP, "destination.port": 873,
                          "network.transport": "tcp", "source.bytes": sorteio.randint(2_000_000_000, 9_000_000_000),
                          "destination.bytes": sorteio.randint(40_000, 90_000)})


def processos(ambiente: Ambiente, sorteio: random.Random) -> Iterator[Dict]:
    for dia in range(DIAS_DO_PERIODO):
        for pessoa in ambiente.pessoas:
            yield evento("edr", momento(dia, 11, sorteio.randint(0, 59)), "Processo iniciado",
                         {"host.name": pessoa.estacao, "user.name": pessoa.conta, "process.name": "OneDriveUpdater.exe",
                          "process.executable": ONEDRIVE_LEGITIMO, "process.parent.name": "OneDrive.exe",
                          "process.hash.sha256": HASH_ONEDRIVE_LEGITIMO})
            for _ in range(sorteio.randint(8, 16)):
                nome, caminho, pai = sorteio.choice(PROCESSOS_COMUNS)
                yield evento("edr", momento(dia, sorteio.randint(11, 21), sorteio.randint(0, 59)), "Processo iniciado",
                             {"host.name": pessoa.estacao, "user.name": pessoa.conta, "process.name": nome,
                              "process.executable": caminho, "process.parent.name": pai})


def arquivos(ambiente: Ambiente, sorteio: random.Random) -> Iterator[Dict]:
    for dia in range(DIAS_DO_PERIODO):
        for servidor in ambiente.servidores_de_arquivos:
            for indice in range(sorteio.randint(250, 320)):
                yield evento("fileserver", momento(dia, 1, indice // 12, indice % 60), "Arquivo renomeado",
                             {"host.name": servidor, "user.name": "svc_backup", "process.name": "BackupAgent.exe",
                              "file.path": rf"D:\Compartilhado\temp\lote_{dia}_{indice:04d}.bak",
                              "file.extension": "bak"})
            for _ in range(sorteio.randint(300, 420)):
                pessoa = sorteio.choice(ambiente.pessoas)
                yield evento("fileserver", momento(dia, sorteio.randint(11, 21), sorteio.randint(0, 59), sorteio.randint(0, 59)),
                             "Arquivo modificado",
                             {"host.name": servidor, "user.name": pessoa.conta, "process.name": "explorer.exe",
                              "file.path": rf"D:\Compartilhado\{pessoa.conta}\relatorio_{sorteio.randint(1, 60)}.xlsx",
                              "file.extension": "xlsx"})


def eventos_de_fundo(ambiente: Ambiente, sorteio: random.Random) -> List[Dict]:
    fontes = (vpn_do_expediente(ambiente, sorteio), sonda_mal_configurada(), logons(ambiente, sorteio),
              inventario_do_diretorio(), resolucoes(ambiente, sorteio), fluxos(ambiente, sorteio),
              processos(ambiente, sorteio), arquivos(ambiente, sorteio))
    return [documento for fonte in fontes for documento in fonte]
