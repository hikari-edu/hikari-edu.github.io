"""Estudo de caso 1 — Da força bruta ao privilégio.

Uma origem externa tenta dezenas de contas na VPN de madrugada, uma delas cede,
e a sessão serve de ponte para um RDP num servidor financeiro, onde nasce uma
conta nova no grupo Administradores. A isca é a sonda de monitoramento, que
tem mais falhas que o atacante, mas numa conta só e sem nunca entrar.
"""

import random
from datetime import timedelta
from typing import Dict, List

from .ambiente import Ambiente
from .modelo import evento, momento
from .perguntas import EstudoDeCaso, Pergunta

ATACANTE_IP = "203.0.113.77"
CONTA_COMPROMETIDA = "c.moura"
ENDERECO_ATRIBUIDO = "10.8.200.23"
SERVIDOR_ALVO = "SRV-FIN-02"
CONTA_CRIADA = "svc_relatorios"
CONTAS_TENTADAS = 62
INICIO_DO_ATAQUE = momento(1, 4, 10)
SUCESSO = momento(1, 5, 17, 43)


def _contas_tentadas(ambiente: Ambiente, sorteio: random.Random) -> List[str]:
    existentes = [pessoa.conta for pessoa in ambiente.pessoas if pessoa.conta != CONTA_COMPROMETIDA]
    inventadas = ["admin", "administrator", "suporte", "teste", "vpn", "backup", "root", "operador"]
    return sorteio.sample(existentes, CONTAS_TENTADAS - 1 - len(inventadas)) + inventadas + [CONTA_COMPROMETIDA]


def _forca_bruta(ambiente: Ambiente, sorteio: random.Random) -> List[Dict]:
    eventos = []
    instante = INICIO_DO_ATAQUE
    lista = _contas_tentadas(ambiente, sorteio)
    for _ in range(17):
        # A mesma lista em ordem diferente a cada rodada, como faz um dicionário.
        for conta in sorteio.sample(lista, len(lista)):
            instante += timedelta(seconds=sorteio.randint(3, 5))
            if instante >= SUCESSO:
                return eventos
            eventos.append(evento("vpn", instante, "Autenticação VPN falhou",
                                  {"source.ip": ATACANTE_IP, "source.geo.country_iso_code": "RU",
                                   "user.name": conta, "host.name": "VPN-GW-01"},
                                  desfecho="failure", severidade=1))
    return eventos


def _sessao_e_privilegio() -> List[Dict]:
    origem = {"source.ip": ATACANTE_IP, "source.geo.country_iso_code": "RU", "user.name": CONTA_COMPROMETIDA,
              "host.name": "VPN-GW-01"}
    no_servidor = {"host.name": SERVIDOR_ALVO, "source.ip": ENDERECO_ATRIBUIDO, "user.name": CONTA_COMPROMETIDA}
    return [
        evento("vpn", SUCESSO, "Sessão VPN estabelecida", {**origem, "client.nat.ip": ENDERECO_ATRIBUIDO}),
        evento("auth", SUCESSO + timedelta(minutes=6, seconds=27), "Logon remoto concluído",
               {**no_servidor, "event.code": "4624", "winlog.logon.type": "10"}),
        evento("auth", SUCESSO + timedelta(minutes=13, seconds=5), "Conta de usuário criada",
               {**no_servidor, "event.code": "4720", "target.user.name": CONTA_CRIADA}, severidade=3),
        evento("auth", SUCESSO + timedelta(minutes=13, seconds=52), "Membro adicionado a grupo local",
               {**no_servidor, "event.code": "4732", "target.user.name": CONTA_CRIADA, "group.name": "Administradores"},
               severidade=4),
        evento("vpn", SUCESSO + timedelta(minutes=47), "Túnel VPN encerrado", origem),
    ]


def eventos(ambiente: Ambiente, sorteio: random.Random) -> List[Dict]:
    return _forca_bruta(ambiente, sorteio) + _sessao_e_privilegio()


ESTUDO = EstudoDeCaso(
    numero=1,
    titulo="Da força bruta ao privilégio",
    hipotese="Se alguém adivinhou uma senha da VPN, a mesma origem externa acumula falhas em muitas contas "
             "diferentes e, em algum momento, uma sessão bem-sucedida.",
    perguntas=[
        Pergunta(chave="c1-origem", caso=1, categoria="Acesso a Credenciais", titulo="A Origem Que Entrou", nivel="Médio",
                 enunciado="A VPN registrou milhares de falhas de autenticação no período. Informe o endereço de "
                           "origem que tentou muitas contas diferentes e conseguiu estabelecer uma sessão.",
                 dica="O endereço com mais falhas não é o do ataque: conte contas distintas por origem, e não eventos.",
                 resposta=ATACANTE_IP,
                 busca='event.dataset:"vpn" and event.outcome:"failure"  →  agrupar source.ip por contagem única de user.name',
                 raciocinio="A sonda de monitoramento tem mais falhas, mas numa conta só e nunca entra. O ataque "
                            "aparece quando a pergunta vira quantas contas cada origem tentou."),
        Pergunta(chave="c1-contas", caso=1, categoria="Acesso a Credenciais", titulo="O Tamanho da Lista", nivel="Fácil",
                 enunciado="Quantas contas distintas a origem do ataque tentou na VPN?",
                 dica="Filtre pela origem do ataque e conte valores distintos de user.name, inclusive a que cedeu.",
                 resposta=str(CONTAS_TENTADAS),
                 busca='event.dataset:"vpn" and source.ip:"203.0.113.77"  →  contagem única de user.name',
                 raciocinio="Contas inexistentes na lista (admin, root, teste) denunciam dicionário, não erro de digitação."),
        Pergunta(chave="c1-conta", caso=1, categoria="Acesso Inicial", titulo="A Conta Que Cedeu", nivel="Fácil",
                 enunciado="Qual conta a origem do ataque conseguiu usar para abrir a sessão na VPN?",
                 dica="Entre os eventos da origem do ataque, separe os de sucesso.",
                 resposta=CONTA_COMPROMETIDA,
                 busca='event.dataset:"vpn" and source.ip:"203.0.113.77" and event.outcome:"success"',
                 raciocinio="A mesma conta tem sessões legítimas vindas do Brasil; a desta madrugada vem de outro país."),
        Pergunta(chave="c1-instante", caso=1, categoria="Triagem e Métricas", titulo="O Minuto Zero", nivel="Médio",
                 enunciado="Informe o carimbo de tempo, como o campo @timestamp o guarda, da sessão VPN que o "
                           "atacante estabeleceu.",
                 dica="É o único evento de sucesso da origem do ataque com a ação de sessão estabelecida.",
                 resposta="2026-03-10T05:17:43.000Z",
                 busca='event.dataset:"vpn" and source.ip:"203.0.113.77" and event.action:"Sessão VPN estabelecida"',
                 raciocinio="Fixar o minuto zero delimita a janela de tudo o que vem depois."),
        Pergunta(chave="c1-servidor", caso=1, categoria="Movimentação Lateral", titulo="A Ponte Para Dentro", nivel="Difícil",
                 enunciado="Com a sessão aberta, o atacante recebeu um endereço interno da VPN e o usou para um "
                           "logon remoto. Em qual servidor?",
                 dica="O endereço atribuído fica no evento da sessão (client.nat.ip). Procure-o como origem nos "
                      "eventos de autenticação.",
                 resposta=SERVIDOR_ALVO,
                 busca='event.dataset:"auth" and source.ip:"10.8.200.23" and winlog.logon.type:"10"',
                 raciocinio="O pivô é o endereço, não a conta: a conta tem logons legítimos em outros lugares."),
        Pergunta(chave="c1-persistencia", caso=1, categoria="Persistência", titulo="O Novo Administrador", nivel="Difícil",
                 enunciado="No servidor acessado, uma conta foi criada e posta no grupo Administradores. Qual?",
                 dica="Procure os eventos 4720 e 4732 no servidor e leia a conta alvo (target.user.name).",
                 resposta=CONTA_CRIADA,
                 busca='event.dataset:"auth" and host.name:"SRV-FIN-02" and event.code:("4720" or "4732")',
                 raciocinio="Persistência: mesmo trocando a senha de c.moura, a conta nova continua dando acesso."),
    ],
)
