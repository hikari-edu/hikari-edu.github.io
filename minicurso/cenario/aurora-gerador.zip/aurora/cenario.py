"""Monta a Aurora Telecom inteira: o dia a dia e os três ataques, com o gabarito preenchido."""

import random
from typing import Dict, List

from pydantic import BaseModel

from . import caso1, caso2, caso3
from .ambiente import criar_ambiente
from .modelo import numerar
from .perguntas import EstudoDeCaso
from .ruido import eventos_de_fundo

SEMENTE = 20261015


class Cenario(BaseModel):
    eventos: List[Dict]
    estudos: List[EstudoDeCaso]


def montar(semente: int = SEMENTE) -> Cenario:
    sorteio = random.Random(semente)
    ambiente = criar_ambiente(sorteio)
    eventos_do_caso2 = caso2.eventos(ambiente, sorteio)
    eventos = numerar(eventos_de_fundo(ambiente, sorteio) + caso1.eventos(ambiente, sorteio)
                      + eventos_do_caso2 + caso3.eventos(ambiente, sorteio))
    estudo2 = caso2.ESTUDO.model_copy(deep=True)
    for pergunta in estudo2.perguntas:
        if pergunta.chave == "c2-volume":
            pergunta.resposta = caso2.megabytes_exfiltrados(eventos_do_caso2)
    return Cenario(eventos=eventos, estudos=[caso1.ESTUDO, estudo2, caso3.ESTUDO])
