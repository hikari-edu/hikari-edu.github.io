"""Cenário do minicurso: a Aurora Telecom, uma operadora fictícia sob três ataques."""
