"""Transforma o cenário do minicurso em pacotes da Biblioteca de desafios do Hikari.

Os três estudos de caso viram três trilhas: cada pergunta é um desafio, e a
seguinte só abre quando a anterior cai, na ordem em que o caçador pivota. Toda
a evidência entra na largada, presa ao primeiro desafio: o minicurso ensina a
caçar, e não a esperar onda.

Gera dois pacotes: o dos três estudos de caso (minicurso-aurora.zip) e a Ponte
para a Arena (minicurso-ponte.zip), que treina os mesmos gestos com registros no
formato do QRadar, o da competição.

Uso:  python3 empacotar.py [--pasta saida]
"""

import argparse
import json
import zipfile
from pathlib import Path
from typing import Dict, List, Optional

from aurora import ponte
from aurora.cenario import montar
from aurora.conferencia import conferir
from aurora.perguntas import EstudoDeCaso, Pergunta

PACOTE_DOS_CASOS = ("minicurso-aurora", "Minicurso de Threat Hunting — Aurora Telecom")
PACOTE_DA_PONTE = ("minicurso-ponte", "Minicurso de Threat Hunting — Ponte para a Arena")
CUSTO_DA_DICA = {"Fácil": 20, "Médio": 40, "Difícil": 60}
ESCOPO = "Considere todo o período retido no SIEM: a janela narrada situa o caso, não limita a busca."


def descricao(estudo: EstudoDeCaso, pergunta: Pergunta) -> str:
    return (f"{pergunta.enunciado}\n\n"
            f"Estudo de caso {estudo.numero} — {estudo.titulo}. Hipótese de partida: {estudo.hipotese}\n\n"
            f"{ESCOPO}")


def licao(pergunta: Pergunta) -> Dict:
    return {"answer": f"flag{{{pergunta.resposta}}}",
            "how_to_solve": f"1. No SIEM, busque:\n\n    {pergunta.busca}\n\n2. {pergunta.dica}\n\n"
                            f"3. O resultado é flag{{{pergunta.resposta}}}.",
            "worth_knowing": pergunta.raciocinio}


def arquivo_de_evidencia(chave_do_pacote: str) -> str:
    return f"logs/{chave_do_pacote}.json"


def desafio(estudo: EstudoDeCaso, pergunta: Pergunta, anterior: Optional[Pergunta], evidencia: Optional[str]) -> Dict:
    return {
        "key": pergunta.chave, "name": pergunta.titulo, "category": pergunta.categoria,
        "description": descricao(estudo, pergunta), "flag": f"flag{{{pergunta.resposta}}}",
        "flags_alternativas": [], "value": pergunta.valor, "state": "visible",
        "prerequisites": [anterior.chave] if anterior else [],
        "log_file": evidencia,
        "difficulty": pergunta.nivel, "hints": [{"content": pergunta.dica, "cost": CUSTO_DA_DICA[pergunta.nivel]}],
        "max_attempts": 0, "case_insensitive": True, "lesson": licao(pergunta),
    }


def desafios(estudos: List[EstudoDeCaso], evidencia: str) -> List[Dict]:
    lista = []
    for estudo in estudos:
        anterior = None
        for pergunta in estudo.perguntas:
            lista.append(desafio(estudo, pergunta, anterior, evidencia if not lista else None))
            anterior = pergunta
    return lista


def gravar(destino: Path, pacote: tuple, estudos: List[EstudoDeCaso], eventos: List[Dict]) -> None:
    chave, nome = pacote
    evidencia = arquivo_de_evidencia(chave)
    manifesto = {"format_version": 1, "package_key": chave, "display_name": nome,
                 "challenges": desafios(estudos, evidencia)}
    destino.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(destino, "w", zipfile.ZIP_DEFLATED) as arquivo:
        arquivo.writestr("manifest.json", json.dumps(manifesto, ensure_ascii=False, indent=2))
        arquivo.writestr(evidencia, json.dumps(eventos, ensure_ascii=False))
    print(f"{destino}: {len(manifesto['challenges'])} desafios, {len(eventos)} eventos")


def main(pasta: Path) -> None:
    cenario = montar()
    perguntas = [pergunta for estudo in cenario.estudos for pergunta in estudo.perguntas]
    if not all(resultado.confere for resultado in conferir(cenario.eventos, perguntas)):
        raise SystemExit("O gabarito não confere; o pacote não foi gravado. Rode gerar.py para ver o motivo.")
    eventos_da_ponte = ponte.eventos()
    divergentes = {chave: par for chave, par in ponte.conferir(eventos_da_ponte).items() if par[0] != par[1]}
    if divergentes:
        raise SystemExit(f"O gabarito da ponte não confere: {divergentes}")
    gravar(pasta / "minicurso-aurora.zip", PACOTE_DOS_CASOS, cenario.estudos, cenario.eventos)
    gravar(pasta / "minicurso-ponte.zip", PACOTE_DA_PONTE, [ponte.ESTUDO], eventos_da_ponte)


if __name__ == "__main__":
    analisador = argparse.ArgumentParser(description=__doc__)
    analisador.add_argument("--pasta", type=Path, default=Path(__file__).parent / "saida")
    main(analisador.parse_args().pasta)
