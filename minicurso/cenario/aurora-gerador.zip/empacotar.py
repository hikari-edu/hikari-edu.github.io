"""Transforma o cenário do minicurso num pacote da Biblioteca de desafios do Hikari.

Os três estudos de caso viram três trilhas: cada pergunta é um desafio, e a
seguinte só abre quando a anterior cai, na ordem em que o caçador pivota. Toda
a evidência entra na largada, presa ao primeiro desafio: o minicurso ensina a
caçar, e não a esperar onda.

Uso:  python3 empacotar.py [--destino saida/minicurso-aurora.zip]
"""

import argparse
import json
import zipfile
from pathlib import Path
from typing import Dict, List, Optional

from aurora.cenario import montar
from aurora.conferencia import conferir
from aurora.perguntas import EstudoDeCaso, Pergunta

CHAVE_DO_PACOTE = "minicurso-aurora"
ARQUIVO_DE_EVIDENCIA = f"logs/{CHAVE_DO_PACOTE}.json"
CUSTO_DA_DICA = {"Fácil": 20, "Médio": 40, "Difícil": 60}
ESCOPO = "Considere todo o período retido no SIEM: a janela narrada situa o caso, não limita a busca."


def descricao(estudo: EstudoDeCaso, pergunta: Pergunta) -> str:
    return (f"{pergunta.enunciado}\n\n"
            f"Estudo de caso {estudo.numero} — {estudo.titulo}. Hipótese de partida: {estudo.hipotese}\n\n"
            f"{ESCOPO}")


def licao(pergunta: Pergunta) -> Dict:
    return {"answer": f"flag{{{pergunta.resposta}}}",
            "how_to_solve": f"1. No SIEM, busque:\n\n    {pergunta.busca}\n\n2. {pergunta.dica}\n\n"
                            f"3. O resultado é flag{{{pergunta.resposta}}}.",
            "worth_knowing": pergunta.raciocinio}


def desafio(estudo: EstudoDeCaso, pergunta: Pergunta, anterior: Optional[Pergunta], com_evidencia: bool) -> Dict:
    return {
        "key": pergunta.chave, "name": pergunta.titulo, "category": pergunta.categoria,
        "description": descricao(estudo, pergunta), "flag": f"flag{{{pergunta.resposta}}}",
        "flags_alternativas": [], "value": pergunta.valor, "state": "visible",
        "prerequisites": [anterior.chave] if anterior else [],
        "log_file": ARQUIVO_DE_EVIDENCIA if com_evidencia else None,
        "difficulty": pergunta.nivel, "hints": [{"content": pergunta.dica, "cost": CUSTO_DA_DICA[pergunta.nivel]}],
        "max_attempts": 0, "case_insensitive": True, "lesson": licao(pergunta),
    }


def desafios(estudos: List[EstudoDeCaso]) -> List[Dict]:
    lista = []
    for estudo in estudos:
        anterior = None
        for pergunta in estudo.perguntas:
            lista.append(desafio(estudo, pergunta, anterior, com_evidencia=not lista))
            anterior = pergunta
    return lista


def main(destino: Path) -> None:
    cenario = montar()
    perguntas = [pergunta for estudo in cenario.estudos for pergunta in estudo.perguntas]
    if not all(resultado.confere for resultado in conferir(cenario.eventos, perguntas)):
        raise SystemExit("O gabarito não confere; o pacote não foi gravado. Rode gerar.py para ver o motivo.")
    manifesto = {"format_version": 1, "package_key": CHAVE_DO_PACOTE,
                 "display_name": "Minicurso de Threat Hunting — Aurora Telecom",
                 "challenges": desafios(cenario.estudos)}
    destino.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(destino, "w", zipfile.ZIP_DEFLATED) as pacote:
        pacote.writestr("manifest.json", json.dumps(manifesto, ensure_ascii=False, indent=2))
        pacote.writestr(ARQUIVO_DE_EVIDENCIA, json.dumps(cenario.eventos, ensure_ascii=False))
    print(f"{destino}: {len(manifesto['challenges'])} desafios, {len(cenario.eventos)} eventos")


if __name__ == "__main__":
    analisador = argparse.ArgumentParser(description=__doc__)
    analisador.add_argument("--destino", type=Path, default=Path(__file__).parent / "saida" / "minicurso-aurora.zip")
    main(analisador.parse_args().destino)
