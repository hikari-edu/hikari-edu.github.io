"""O cenário do minicurso só serve se o gabarito conferir, as iscas enganarem e a geração se repetir."""

import hashlib
import json
import sys
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from aurora.cenario import montar  # noqa: E402
from aurora.conferencia import conferir, iscas_que_enganam  # noqa: E402


@pytest.fixture(scope="module")
def cenario():
    return montar()


def perguntas_de(cenario):
    return [pergunta for estudo in cenario.estudos for pergunta in estudo.perguntas]


def test_cada_resposta_sai_da_busca_que_a_pergunta_descreve(cenario):
    reprovados = [r for r in conferir(cenario.eventos, perguntas_de(cenario)) if not r.confere]
    assert reprovados == []


def test_o_caminho_ingenuo_leva_a_outra_resposta(cenario):
    assert all(iscas_que_enganam(cenario.eventos, perguntas_de(cenario)).values())


def test_a_mesma_semente_gera_o_mesmo_cenario(cenario):
    def resumo(eventos):
        return hashlib.sha256(json.dumps(eventos, sort_keys=True).encode()).hexdigest()
    assert resumo(montar().eventos) == resumo(cenario.eventos)


def test_nenhum_enunciado_ou_dica_entrega_a_resposta(cenario):
    for pergunta in perguntas_de(cenario):
        if len(pergunta.resposta) >= 4:
            assert pergunta.resposta.lower() not in (pergunta.enunciado + pergunta.dica).lower(), pergunta.chave


def test_tres_estudos_com_perguntas_de_todos_os_niveis(cenario):
    assert [estudo.numero for estudo in cenario.estudos] == [1, 2, 3]
    for estudo in cenario.estudos:
        assert {pergunta.nivel for pergunta in estudo.perguntas} == {"Fácil", "Médio", "Difícil"}


def test_a_ponte_confere_pelo_caminho_do_cacador():
    from aurora import ponte

    divergentes = {chave: par for chave, par in ponte.conferir(ponte.eventos()).items() if par[0] != par[1]}
    assert divergentes == {}


def test_a_ponte_usa_campos_com_espaco_como_na_competicao():
    from aurora import ponte

    campos = set().union(*(documento.keys() for documento in ponte.eventos()))
    assert {"Source IP", "Event Name", "Username"} <= campos


def test_a_ponte_se_repete_com_a_mesma_semente():
    from aurora import ponte

    assert ponte.eventos() == ponte.eventos()
